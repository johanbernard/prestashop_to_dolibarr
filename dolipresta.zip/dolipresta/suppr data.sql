SET foreign_key_checks = 0;
delete from llx_facture;
delete from llx_facturedet;
delete from llx_societe;
delete from llx_product;
delete from llx_product_price;
delete from llx_commande;
delete from llx_commandedet;
SET foreign_key_checks = 1;